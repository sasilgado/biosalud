

<?php $__env->startSection('title', 'Home'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="slider">
      <div class="img-responsive">
        <ul class="bxslider">
          <li><img src="img/01.jpg" alt="" /></li>
          <li><img src="img/01.jpg" alt="" /></li>
          <li><img src="img/01.jpg" alt="" /></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div class="text-center">
        <h2>Multi Purpose Theme</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu<br> vestibulum volutpat libero sollicitudin vitae Curabitur ac aliquam <br> lorem sit amet scelerisque justo</p>
      </div>
      <hr>
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="box">
      <div class="col-md-4">
        <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="0.4s">
          <h4>Mision</h4>
          <div class="icon">
            <i class="fa fa-heart-o fa-3x"></i>
          </div>
          <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu libero</p>
          <div class="ficon">
            <a href="#" class="btn btn-default" role="button">Read more</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="1.0s">
          <h4>Multi Purpose</h4>
          <div class="icon">
            <i class="fa fa-desktop fa-3x"></i>
          </div>
          <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu libero</p>
          <div class="ficon">
            <a href="#" class="btn btn-default" role="button">Read more</a>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="wow bounceIn" data-wow-offset="0" data-wow-delay="1.6s">
          <h4>Easy Customize</h4>
          <div class="icon">
            <i class="fa fa-location-arrow fa-3x"></i>
          </div>
          <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu libero</p>
          <div class="ficon">
            <a href="#" class="btn btn-default" role="button">Read more</a>
          </div>
        </div>

      </div>

    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div class="text-center">
        <h2>Galleries</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Cras suscipit arcu<br> vestibulum volutpat libero sollicitudin vitae Curabitur ac aliquam <br>
        </p>
      </div>
      <hr>
    </div>
  </div>
</div>

<div class="content">
  <div class="grid">
    <figure class="effect-zoe">
      <img src="/img/25.jpg" alt="img25" />
      <figcaption>
        <h2>Title <span>Name</span></h2>
        <p class="icon-links">
          <a href="#"><span class="icon-heart"></span></a>
          <a href="#"><span class="icon-eye"></span></a>
          <a href="#"><span class="icon-paper-clip"></span></a>
        </p>
        <p class="description">Zoe never had the patience of her sisters. She deliberately punched the bear in his face.</p>
      </figcaption>
    </figure>
    <figure class="effect-zoe">
      <img src="img/26.jpg" alt="img26" />
      <figcaption>
        <h2>Title <span>Name</span></h2>
        <p class="icon-links">
          <a href="#"><span class="icon-heart"></span></a>
          <a href="#"><span class="icon-eye"></span></a>
          <a href="#"><span class="icon-paper-clip"></span></a>
        </p>
        <p class="description">Zoe never had the patience of her sisters. She deliberately punched the bear in his face.</p>
      </figcaption>
    </figure>
  </div>
</div>

<div class="content">
  <div class="grid">
    <figure class="effect-zoe">
      <img src="img/27.jpg" alt="img27" />
      <figcaption>
        <h2>Title <span>Name</span></h2>
        <p class="icon-links">
          <a href="#"><span class="icon-heart"></span></a>
          <a href="#"><span class="icon-eye"></span></a>
          <a href="#"><span class="icon-paper-clip"></span></a>
        </p>
        <p class="description">Zoe never had the patience of her sisters. She deliberately punched the bear in his face.</p>
      </figcaption>
    </figure>
    <figure class="effect-zoe">
      <img src="img/30.jpg" alt="img30" />
      <figcaption>
        <h2>Title <span>Name</span></h2>
        <p class="icon-links">
          <a href="#"><span class="icon-heart"></span></a>
          <a href="#"><span class="icon-eye"></span></a>
          <a href="#"><span class="icon-paper-clip"></span></a>
        </p>
        <p class="description">Zoe never had the patience of her sisters. She deliberately punched the bear in his face.</p>
      </figcaption>
    </figure>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/animate.css">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/jquery.bxslider.css">
    <link rel="stylesheet" type="text/css" href="/css/normalize.css" />
    <link rel="stylesheet" type="text/css" href="/css/demo.css" />
    <link rel="stylesheet" type="text/css" href="/css/set1.css" />
    <link href="/css/overwrite.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@700&display=swap" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="/js/jquery-2.1.1.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/wow.min.js"></script>
    <script src="/js/jquery.easing.1.3.js"></script>
    <script src="/js/jquery.isotope.min.js"></script>
    <script src="/js/jquery.bxslider.min.js"></script>
    <script type="text/javascript" src="/js/fliplightbox.min.js"></script>
    <script src="/js/functions.js"></script>
    <script type="text/javascript">
      $('.portfolio').flipLightBox()
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\larajet\resources\views/home.blade.php ENDPATH**/ ?>